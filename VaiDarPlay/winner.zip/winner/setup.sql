-- Rode no SQL Editor do Supabase. Se já rodou a versão anterior (sem dados reais), apague antes:
-- drop view if exists court_current; drop table if exists court_status_events cascade;

create table if not exists courts (
  id int generated always as identity primary key,
  slug text not null unique check (slug ~ '^[a-z0-9-]{2,30}$'),
  name text not null check (char_length(name) between 2 and 40),
  type text not null check (type in ('saibro','beach_tenis','padel','outro')),
  sort int not null default 0,
  active boolean not null default true
);
create table if not exists app_settings (key text primary key, value text not null);
insert into app_settings values ('admin_pin','TROQUE-ESTE-PIN') on conflict do nothing;
-- depois de rodar, troque: update app_settings set value = 'SEU-PIN' where key = 'admin_pin';

create table if not exists court_status_events (
  id bigint generated always as identity primary key,
  court_id int not null references courts(id),
  status text not null check (status in ('livre','restricao','molhada','interditada')),
  author text not null check (char_length(author) between 2 and 40),
  note text check (char_length(note) <= 140),
  created_at timestamptz not null default now()
);
create index if not exists idx_events_court_time on court_status_events (court_id, created_at desc);

create or replace view court_current with (security_invoker = true) as
  select c.id as court_id, c.slug, c.name, c.type, c.sort, e.status, e.author, e.note, e.created_at
  from courts c
  left join lateral (select * from court_status_events x where x.court_id = c.id order by x.created_at desc limit 1) e on true
  where c.active;

alter table courts enable row level security;
alter table app_settings enable row level security;   -- sem policies: ninguém de fora lê o PIN
alter table court_status_events enable row level security;
create policy "ler quadras" on courts for select to anon using (true);
create policy "ler eventos" on court_status_events for select to anon using (true);
create policy "inserir eventos" on court_status_events for insert to anon
  with check (exists (select 1 from courts where id = court_id and active));
grant select on courts to anon;
grant select, insert on court_status_events to anon;
grant select on court_current to anon;
-- cadastro de quadras só pela função abaixo, com PIN (sem insert/update/delete direto)

create or replace function save_court(p_pin text, p_slug text, p_name text, p_type text, p_sort int, p_active boolean)
returns void language plpgsql security definer set search_path = public as $$
begin
  if p_pin is distinct from (select value from app_settings where key = 'admin_pin') then
    perform pg_sleep(1);
    raise exception 'PIN incorreto.';
  end if;
  insert into courts (slug, name, type, sort, active) values (p_slug, p_name, p_type, p_sort, p_active)
  on conflict (slug) do update set name = excluded.name, type = excluded.type, sort = excluded.sort, active = excluded.active;
end $$;
grant execute on function save_court(text,text,text,text,int,boolean) to anon;

create or replace function limit_rate() returns trigger language plpgsql as $$
begin
  if exists (select 1 from court_status_events where court_id = new.court_id and created_at > now() - interval '15 seconds') then
    raise exception 'Aguarde alguns segundos para atualizar de novo.';
  end if;
  return new;
end $$;
drop trigger if exists t_rate on court_status_events;
create trigger t_rate before insert on court_status_events for each row execute function limit_rate();

-- quadras de saibro iniciais (beach tênis e pádel você cadastra em /winner/admin.html)
insert into courts (slug, name, type, sort)
select 'q'||g, 'Quadra '||g, 'saibro', g from generate_series(1,7) g on conflict (slug) do nothing;
