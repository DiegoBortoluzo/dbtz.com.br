# Winner: status das quadras (v1, atualização humana)

1. Supabase: crie um projeto (ou use um existente) e rode `setup.sql` no SQL Editor.
2. Troque o PIN de administrador (comando no próprio setup.sql): `update app_settings set value = 'SEU-PIN' where key = 'admin_pin';`
3. Em Project Settings > API, copie a Project URL e a anon public key para `config.js`.
   A anon key é pública por natureza; a proteção está nas regras do banco.
4. Envie a pasta `winner` para a raiz pública de dbtz.com.br (FTP ou gerenciador de arquivos).
5. Abra dbtz.com.br/winner/admin.html, informe o PIN e cadastre as quadras de beach tênis e pádel.
6. A lista em admin.html mostra o link de cada quadra (quadra.html?c=codigo). Gere um QR Code por link.

Regras: qualquer pessoa atualiza o estado (nome obrigatório, 1 atualização por quadra a cada 15 s, histórico não pode ser editado nem apagado). Só quem tem o PIN cadastra ou edita quadras. Quadras não são apagadas, só desativadas, para preservar o histórico.
